# 뷰 완전 제거 방식 적용 요약

## 문제점
`clearLayerEffects`를 적용했음에도 불구하고 번역 버튼과 Live 버튼의 흔적이 여전히 사라지지 않는 문제가 지속되었습니다. 이는 단순히 레이어 효과를 제거하거나 `isHidden = true`로 숨기는 것만으로는 부족했습니다.

## 해결 방법
뷰와 레이어를 화면에서 완전히 제거하고, 해당 영역의 렌더링을 강제로 갱신하는 방식으로 문제를 해결했습니다.

## 구현 내용

### 1. 뷰 계층 구조에서 완전히 제거
오버레이 모드로 전환 시:
- `removeFromSuperlayer()`로 레이어를 먼저 제거
- `removeFromSuperview()`로 뷰를 계층 구조에서 완전히 제거
- 제거 대상: translateButton, borderView, visualEffectView, instructionLabel, 브랜딩 텍스트, Live UI 요소들

### 2. 뷰 프레임 저장
제거 전에 각 뷰의 프레임을 저장:
```swift
private var translateButtonFrame: NSRect?
private var liveToggleButtonFrame: NSRect?
private var liveIndicatorViewFrame: NSRect?
private var liveDisplayLabelFrame: NSRect?
```

### 3. 부모 뷰의 강제 재드로잉
뷰 제거 후:
- `contentView?.setNeedsDisplay(buttonFrame)`로 각 버튼 영역 재드로잉
- `contentView?.setNeedsDisplay(contentView?.bounds)`로 전체 영역 재드로잉
- `window?.contentView?.setNeedsDisplay(frame)`로 윈도우 레벨 재드로잉

### 4. 뷰 복원 시 재추가
뷰파인더 모드로 돌아올 때:
- `if view.superview == nil` 체크로 제거된 뷰 확인
- 저장된 프레임으로 원래 위치 복원
- `addSubview()`로 뷰 계층에 다시 추가
- 원래의 레이어 효과들(그림자, 테두리 등) 재적용

## 주요 변경 코드

### showOverlayInternal 메서드
```swift
// 뷰들의 프레임 저장
translateButtonFrame = translateButton?.frame
liveToggleButtonFrame = liveToggleButton?.frame

// 레이어 먼저 제거
translateButton?.layer?.removeFromSuperlayer()
borderView?.layer?.removeFromSuperlayer()

// 뷰 계층에서 제거
visualEffectView?.removeFromSuperview()
translateButton?.removeFromSuperview()
borderView?.removeFromSuperview()

// 강제 재그리기
contentView?.setNeedsDisplay(buttonFrame)
window?.contentView?.setNeedsDisplay(frame)
```

### hideOverlay 메서드
```swift
// 뷰가 제거되었다면 다시 추가
if translateButton.superview == nil {
    if let savedFrame = translateButtonFrame {
        translateButton.frame = savedFrame
    }
    contentView?.addSubview(translateButton)
}

// 레이어 효과 복원
translateButton.layer?.shadowOpacity = 0.2
translateButton.layer?.shadowRadius = 2
// ... 기타 효과들
```

## 기대 효과
1. **완전한 제거**: 뷰와 관련된 모든 렌더링 리소스가 완전히 정리됨
2. **흔적 없는 화면**: 버튼의 그림자나 테두리 흔적이 전혀 남지 않음
3. **깨끗한 전환**: 오버레이 모드와 뷰파인더 모드 간 전환이 깨끗함
4. **정확한 복원**: 뷰파인더 모드로 돌아올 때 모든 UI가 원래대로 복원됨

## 핵심 원칙
이제부터 버튼을 숨길 때는 `isHidden` 속성이나 효과 제거가 아닌, `removeFromSuperview()`를 사용하는 것이 기본 원칙입니다. 이것이 뷰와 관련된 모든 렌더링 리소스를 가장 확실하게 정리하는 방법입니다.