# OCR 언어 인식 문제 수정 요약

## 문제 진단
- **증상**: Live 모드에서 한글 "테스트"가 "印亼巨" 또는 "E亼上"로 잘못 인식됨
- **원인**: Live 모드의 OCR 언어 우선순위가 일본어로 설정되어 있어 한글을 일본어/중국어 문자로 오인식

## 잘못된 접근 (되돌림)
1. 오버레이 숨김/표시 기능 구현
   - 실제 문제는 오버레이가 아니라 OCR 언어 설정이었음
   - 오버레이를 숨기면 정상적인 번역 표시가 사라지는 부작용 발생

## 올바른 해결책
1. **오버레이 숨김 코드 제거**
   - `CaptureFinderWindow.swift`: `temporarilyHideOverlay()`, `restoreOverlay()` 메서드 삭제
   - `isOverlayMode` 접근 제어자를 다시 private로 복원
   - `LiveTranslationViewModel.swift`: 모든 오버레이 제어 코드 제거

2. **OCR 언어 설정 수정**
   - Live 모드의 `recognitionLanguages` 설정 제거
   - 시스템 기본값을 사용하도록 변경 (Standard 모드와 동일하게)
   - 이렇게 하면 시스템 언어에 따라 자동으로 최적화됨

## 코드 변경 내역

### LiveTranslationViewModel.swift
```swift
// 변경 전:
request.recognitionLanguages = ["ja-JP", "ko-KR", "en-US", "zh-Hans"]  // 일본어를 우선순위로

// 변경 후:
// recognitionLanguages를 설정하지 않아 시스템 기본값 사용 (Standard 모드와 동일)
```

## 결과
- Live 모드에서도 한글 텍스트가 정확히 인식됨
- 오버레이가 정상적으로 표시됨
- Standard 모드와 Live 모드의 OCR 동작이 일관성 있게 통일됨

## 날짜
2025년 6월 29일