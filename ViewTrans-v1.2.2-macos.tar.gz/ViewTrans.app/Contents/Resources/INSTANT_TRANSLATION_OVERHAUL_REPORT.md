# Instant Translation 기능 전면 재설계 보고서

## 개요
ViewTrans의 Instant Translation 기능을 근본적으로 재설계하여 안정성과 사용성을 대폭 개선했습니다.

## 주요 문제점 및 해결 방안

### 1. 심각한 불안정성 및 크래시 (EXC_BAD_ACCESS)
**문제점:**
- 비동기 `translationTask`와 동기 `cleanupUI()` 메서드 간의 race condition
- NSPopover와 NSWindow의 생명주기가 비동기 작업과 동기화되지 않음

**해결 방안:**
- State Machine 도입으로 모든 상태 전환을 순차적으로 관리
- Actor 패턴으로 thread safety 보장
- SafeUIComponentManager로 UI 컴포넌트 생명주기 관리

### 2. 부정확한 텍스트 감지
**문제점:**
- Accessibility API가 커서 위치에 민감하여 자주 실패
- OCR fallback이 고정 크기 영역만 캡처하여 비효율적

**해결 방안:**
- Visual Paragraph Clustering 엔진 개발
- OCR로 주변 텍스트를 모두 감지한 후 시각적 근접성으로 단락 구성
- 커서 위치에서 가장 가까운 단락을 지능적으로 선택

## 새로운 아키텍처

### 1. InstantTranslationStateMachine
```swift
enum InstantTranslationState {
    case idle       // 대기 상태
    case detecting  // 텍스트 감지 중
    case translating // 번역 중
    case displaying // 결과 표시 중
    case cleaning   // 정리 중
}
```

**특징:**
- 모든 상태 전환이 검증됨
- 비정상 상태 전환 방지
- 비상 정리 기능 (forceIdle)

### 2. VisualParagraphDetector
**핵심 알고리즘:**
1. 커서 주변 영역 OCR 수행
2. 텍스트 조각들을 시각적 특성으로 클러스터링
   - 폰트 크기 유사성
   - 수평 정렬
   - 줄 간격
3. 가장 가까운 단락 선택

**장점:**
- 커서가 정확히 텍스트 위에 없어도 작동
- 논리적 단락 단위로 번역
- 성능 최적화 (적응형 검색 반경)

### 3. SafeUIComponentManager
**관리 대상:**
- NSPopover 생명주기
- NSWindow 생명주기
- 자동 리소스 정리

**안전성 기능:**
- Weak reference 사용
- 상태 추적
- 자동 disposed 감지

## 구현 세부사항

### 파일 구조
```
InstantTranslation/
├── InstantTranslationControllerV2.swift    # 새로운 메인 컨트롤러
├── InstantTranslationStateMachine.swift    # 상태 관리
├── VisualParagraphDetector.swift           # 단락 감지 엔진
├── SafeUIComponentManager.swift            # UI 생명주기 관리
└── InstantTranslationController.swift.backup # 기존 백업
```

### 통합 방법
1. AppDelegate에서 `InstantTranslationControllerV2` 사용
2. 기존 API 인터페이스 유지 (performInstantTranslation, cancelTranslation)
3. 다른 기능과의 완전한 격리

## 성능 개선

### 1. 비동기 처리
- 모든 무거운 작업은 백그라운드에서 수행
- UI 업데이트만 MainActor에서 실행

### 2. 적응형 검색
- 초기 반경 200px에서 시작
- 텍스트를 찾을 때까지 점진적 확대
- 최대 400px 제한

### 3. 리소스 관리
- 비활성 UI 컴포넌트 자동 정리
- 작업 취소 시 즉시 리소스 해제

## 테스트 가이드

### 1. 안정성 테스트
- 빠른 연속 호출 시 크래시 없음 확인
- 앱 종료 시 메모리 누수 없음 확인
- 다중 모니터 환경에서 정상 작동

### 2. 기능 테스트
- 커서가 텍스트에서 약간 벗어나도 감지
- 단락 전체가 올바르게 번역됨
- 팝오버가 적절한 위치에 표시됨

### 3. 성능 테스트
- UI 응답성 유지
- 번역 지연 최소화

## 향후 개선 사항

1. **기계학습 기반 단락 감지**
   - 더 정확한 단락 경계 인식
   - 레이아웃 학습

2. **캐싱 메커니즘**
   - 최근 번역 결과 캐싱
   - OCR 결과 캐싱

3. **사용자 설정**
   - 감지 민감도 조절
   - 선호 단락 크기 설정

## 결론
새로운 Instant Translation 엔진은 안정성과 사용성을 크게 개선했습니다. State Machine과 Actor 패턴으로 race condition을 원천 차단했으며, Visual Paragraph Clustering으로 더 지능적인 텍스트 감지가 가능해졌습니다.

기존 기능과의 완벽한 격리로 side effect 없이 통합 가능하며, 향후 확장성도 고려한 설계입니다.