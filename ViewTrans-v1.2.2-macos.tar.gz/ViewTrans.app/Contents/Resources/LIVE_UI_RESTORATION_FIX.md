# Live UI Restoration Fix Report

## Problem Description
Live 모드를 사용한 후 "새로고침" 버튼을 누르면 이전 번역 내용이 흐릿하게 남아있는 문제가 발생했습니다. 특히:
1. Live 버튼 → Live 모드 종료 → 뷰파인더 이동 → 새로고침: 잔상 발생
2. 일반 번역 → 뷰파인더 이동 → 새로고침: 정상 작동

## Root Cause Analysis
1. **Live UI 요소들의 위치 이동**:
   - 초기 상태: Live UI 요소들이 `contentView`에 추가됨
   - 오버레이 모드: `showOverlayInternal`에서 Live UI를 `overlayContainerView`로 이동
   
2. **문제 발생 메커니즘**:
   - Live 모드 시작 → Live UI가 `overlayContainerView`로 이동
   - Live 모드 종료 → `hideOverlay()` 호출
   - `overlayContainerView.isHidden = true` 설정
   - **하지만 Live UI 요소들이 여전히 `overlayContainerView`의 자식으로 남아있음**
   - 새로고침 → 새 오버레이 표시 → `overlayContainerView.isHidden = false`
   - 이전에 남아있던 Live UI 요소들이 다시 보이게 됨

## Solution
`hideOverlay` 메서드에서 Live UI 요소들을 원래 위치(`contentView`)로 복원하는 코드 추가:

```swift
// Live UI 요소들을 원래 위치(contentView)로 복원
if let liveButton = liveToggleButton {
    liveButton.removeFromSuperview()
    contentView?.addSubview(liveButton)
    liveButton.frame = NSRect(x: 8, y: 8, width: 40, height: 20)
}

if let liveIndicator = liveIndicatorView {
    liveIndicator.removeFromSuperview()
    contentView?.addSubview(liveIndicator)
    liveIndicator.frame = NSRect(x: 50, y: 11, width: 12, height: 12)
}

if let liveLabel = liveDisplayLabel {
    liveLabel.removeFromSuperview()
    contentView?.addSubview(liveLabel)
    liveLabel.frame = NSRect(x: 10, y: 40, width: 180, height: 20)
}
```

## Result
- Live UI 요소들이 항상 올바른 위치에 있도록 보장
- 오버레이 모드 종료 시 UI 요소들이 원래 위치로 복원됨
- 새로고침 시 이전 UI 요소들이 남아있지 않음

## Testing Scenarios
1. Live 모드 → 종료 → 새로고침: 잔상 없음
2. Live 모드 → ESC → 새로고침: 잔상 없음
3. 일반 번역 → 새로고침: 정상 작동 (변경 없음)

## Date
June 29, 2025