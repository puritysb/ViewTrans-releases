# Visual Feedback Loop Fix Implementation Summary

## 구현 완료 사항

### Phase 1: HighlightWindowManager 기능 확장 ✅
- `getAllOverlayWindowNumbers()` 메서드가 이미 존재함을 확인 (line 327-360)
- 모든 오버레이 윈도우의 CGWindowID를 수집하여 반환
- screenWindows와 windowsByIdentifier 모두에서 수집하여 중복 제거

### Phase 2: CaptureFilterManager 클래스 신규 생성 ✅
- 파일 위치: `/Users/puritysb/github/ViewTrans/ViewTrans/ViewTrans/Capture/CaptureFilterManager.swift`
- 싱글톤 패턴으로 구현
- 주요 기능:
  - `getAllAppWindowNumbers()`: 모든 앱 윈도우 ID 수집
  - `createContentFilter()`: SCContentFilter 생성 시 앱 윈도우 제외
  - `addExcludedWindow()` / `removeExcludedWindow()`: 동적 윈도우 관리
  - `logCurrentWindowState()`: 디버깅용 상태 로깅

### Phase 3: 신규 아키텍처 통합 ✅
이미 모든 캡처 지점에서 CaptureFilterManager를 사용 중:

1. **LiveTranslationViewModel.swift** (line 148-151)
   ```swift
   let contentFilter = CaptureFilterManager.shared.createContentFilter(
       for: display,
       availableWindows: content.windows
   )
   ```

2. **ScreenCapture.swift** (line 172-175)
   ```swift
   let filter = CaptureFilterManager.shared.createContentFilter(
       for: display,
       availableWindows: shareableContent.windows
   )
   ```

3. **간접 사용 (ScreenCapture 경유)**
   - CaptureManager.swift
   - CursorTextExtractor.swift

## 아키텍처 설계

```
┌─────────────────────────────────────────────────────────┐
│                    CaptureFilterManager                  │
│                      (Singleton)                         │
├─────────────────────────────────────────────────────────┤
│ - getAllAppWindowNumbers()                              │
│   ├─ NSApp.windows 수집                                 │
│   ├─ CaptureFinderWindow 확인                          │
│   ├─ HighlightWindowManager.getAllOverlayWindowNumbers()│
│   └─ additionalExcludedWindowNumbers                   │
│                                                         │
│ - createContentFilter(display, windows)                 │
│   └─ SCContentFilter(display, excludingWindows: [...]) │
└─────────────────────────────────────────────────────────┘
                            ▲
                            │
        ┌───────────────────┼───────────────────┐
        │                   │                   │
┌───────────────┐  ┌────────────────┐  ┌─────────────────┐
│LiveTranslation│  │ ScreenCapture  │  │ CaptureManager  │
│  ViewModel    │  │                │  │ (via SC)        │
└───────────────┘  └────────────────┘  └─────────────────┘
```

## 동작 원리

1. **윈도우 ID 수집**
   - CaptureFilterManager가 앱의 모든 윈도우 ID를 동적으로 수집
   - CaptureFinderWindow (뷰파인더)
   - HighlightOverlayWindow들 (번역 오버레이)
   - 기타 앱 윈도우들

2. **필터 생성**
   - SCShareableContent에서 사용 가능한 윈도우 목록 획득
   - 앱 윈도우 ID와 매칭되는 SCWindow 객체 필터링
   - SCContentFilter 생성 시 excludingWindows 파라미터에 전달

3. **화면 캡처**
   - SCStream 또는 SCScreenshotManager가 필터를 사용
   - 앱 윈도우가 제외된 깨끗한 화면만 캡처

## 테스트 시나리오

1. **Live 모드 테스트**
   - Live 모드 활성화 후 번역 수행
   - 오버레이가 표시된 상태에서 OCR이 정상 작동하는지 확인
   - 오버레이 텍스트가 OCR에 포함되지 않는지 확인

2. **표준 캡처 테스트**
   - 뷰파인더로 텍스트 캡처
   - 번역 오버레이가 표시된 상태에서 재캡처
   - 원본 텍스트만 인식되는지 확인

3. **다중 모니터 테스트**
   - 여러 모니터에 오버레이가 표시된 상태에서 캡처
   - 각 모니터에서 정상 작동하는지 확인

4. **디버깅**
   - `CaptureFilterManager.shared.logCurrentWindowState()` 호출
   - 제외되는 윈도우 목록 확인

## 예상 효과

- OCR이 앱 UI를 인식하지 않음
- 번역 정확도 향상
- 시각적 피드백 루프 완전 차단
- 안정적인 Live 모드 동작